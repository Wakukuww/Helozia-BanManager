package fr.wakukuw.banmanager.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.lang3.ThreadUtils.ThreadIdPredicate;
 
public class MySQL {
    
    private Connection connexion;
    
    public void connect(String host, int port, String database, String user, String password){
        if(!isConnected()){
            try {
                connexion = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + database, user, password);
                System.out.println("[BanSystem] Connexion etablie avec la bdd");
            } catch (SQLException e) {
                e.printStackTrace();
            }
            
            try {
				final PreparedStatement prepareStatementBans = this.getConnection().prepareStatement("CREATE TABLE IF NOT EXISTS bans (player_uuid VARCHAR(37), end BIGINT, reason VARCHAR(32));");
				final PreparedStatement prepareStatementMute = this.getConnection().prepareStatement("CREATE TABLE IF NOT EXISTS mutes (player_uuid VARCHAR(37), end BIGINT, reason VARCHAR(32));");

				final PreparedStatement prepareStatementPlayerInfos = this.getConnection().prepareStatement("CREATE TABLE IF NOT EXISTS player_infos (player_uuid VARCHAR(37), player_name VARCHAR(17), ID INT);");

				prepareStatementBans.executeUpdate();
				prepareStatementPlayerInfos.executeUpdate();
				prepareStatementMute.executeUpdate();

				
			} catch (SQLException e) {
				e.printStackTrace();
			}
            
        }
    }
   
    public void disconnect(){
        if(isConnected()){
            try {
                connexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public boolean isConnected(){
        try {
            if((connexion == null) || (connexion.isClosed()) || connexion.isValid(5)){
                return false;
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public Connection getConnection() {
        return connexion;
    }
 
}