package fr.wakukuw.banmanager.listeners;

import fr.wakukuw.banmanager.Main;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.LoginEvent;
import net.md_5.bungee.api.event.PostLoginEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;

public class PlayerJoin implements Listener {
	 
    @EventHandler
    public void onJoin(PostLoginEvent e){
        ProxiedPlayer player = e.getPlayer();
        Main.getInstance().playerinfos.update(player);
    }
 
    @EventHandler
    public void onLogin(LoginEvent e){
        Main.getInstance().banManager.checkDuration(e.getConnection().getUniqueId());
 
        if(Main.getInstance().banManager.isBanned(e.getConnection().getUniqueId())){
            e.setCancelled(true);
            e.setCancelReason("�cVous �tes banni de Helozia !\n " +
                    "\n " +
                    "�6Raison : �f" + Main.getInstance().banManager.getReason(e.getConnection().getUniqueId()) + "\n " +
                    "\n " +
                    "�aTemps restant : �f" + Main.getInstance().banManager.getTimeLeft(e.getConnection().getUniqueId()) + "\n" +
                    "\n" +
                    "�bPour contester cette sanction, merci de contacter un mod�rateur sur discord ! https://discord.gg/sBKGpNeBEV");
        }
    }

 
}