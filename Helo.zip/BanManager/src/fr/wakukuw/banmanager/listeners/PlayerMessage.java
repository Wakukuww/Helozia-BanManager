package fr.wakukuw.banmanager.listeners;

import fr.wakukuw.banmanager.Main;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.ChatEvent;
import net.md_5.bungee.api.event.PostLoginEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;

public class PlayerMessage implements Listener {
	 
    @EventHandler
    public void onJoin(PostLoginEvent e){
        ProxiedPlayer player = e.getPlayer();
        Main.getInstance().playerinfos.update(player);
    }
    
    @EventHandler
    public void onMessage(ChatEvent e) {
    	ProxiedPlayer player = (ProxiedPlayer) e.getSender();
        Main.getInstance().banManager.checkDuration(player.getUniqueId());
    	
    	if(Main.getInstance().muteManager.isMuted(player.getUniqueId())) {
    		e.setCancelled(true);
    		player.sendMessage("�cVous �tes muet !");
    	}
    	    	
    }
 
}