package fr.wakukuw.banmanager.commands;

import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Command;
 
import java.util.UUID;

import fr.wakukuw.banmanager.Main;
 
public class UnmuteCommand extends Command {
 
    public UnmuteCommand(){
        super("unmute");
    }
 
    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length != 1){
            sender.sendMessage("�c/unmute <joueur>");
            return;
        }
 
        String targetName = args[0];
 
        if(!Main.getInstance().playerinfos.exist(targetName)){
            sender.sendMessage("�cCe joueur ne s'est jamais connect� au serveur !");
            return;
        }
 
        UUID targetUUID = Main.getInstance().playerinfos.getUUID(targetName);
 
        if(!Main.getInstance().muteManager.isMuted(targetUUID)){
            sender.sendMessage("�cCe joueur n'est pas muet !");
            return;
        }
 
        Main.getInstance().muteManager.unmute(targetUUID);
        sender.sendMessage("�aVous avez redonn� la parole �6" + targetName);
        
        
        return;
    }
}