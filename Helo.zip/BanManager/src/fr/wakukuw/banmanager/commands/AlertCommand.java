package fr.wakukuw.banmanager.commands;

import net.md_5.bungee.BungeeCord;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.plugin.Command;

public class AlertCommand extends Command {

	public AlertCommand() {
		super("alert");
	}

	@Override
	public void execute(CommandSender sender, String[] args) {
		
		if(sender.hasPermission("op")) {

		if(args.length <= 0) {
		
		BungeeCord.getInstance().broadcast("�c[Alerte] " + args);
		
		}
		
		else {
			sender.sendMessage("�cMerci de mettre un message");
		}
		
		return;
		}
	}

}
