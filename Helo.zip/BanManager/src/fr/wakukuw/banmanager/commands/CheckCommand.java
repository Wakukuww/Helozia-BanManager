package fr.wakukuw.banmanager.commands;

import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.plugin.Command;
 
import java.util.UUID;

import fr.wakukuw.banmanager.Main;
 
public class CheckCommand extends Command {
 
    public CheckCommand(){
        super("check");
    }
 
	@Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length != 1){
            sender.sendMessage("§c/check <joueur>");
            return;
        }
 
        String targetName = args[0];
 
        if(!Main.getInstance().playerinfos.exist(targetName)){
            sender.sendMessage("§cCe joueur ne s'est jamais connecté au serveur !");
            return;
        }
 
        UUID targetUUID = Main.getInstance().playerinfos.getUUID(targetName);
 
        Main.getInstance().banManager.checkDuration(targetUUID);
 
        sender.sendMessage("§7-----------------------------------------------------");
        sender.sendMessage("§ePseudo : §b" + args[0]);
        sender.sendMessage("§eUUID : §b" + targetUUID.toString());
        sender.sendMessage("§eBanni : " + (Main.getInstance().banManager.isBanned(targetUUID) ? "§a✔" : "§c✖"));
        sender.sendMessage("§eMuet : " + (Main.getInstance().muteManager.isMuted(targetUUID) ? "§a✔" : "§c✖"));
 
        if(Main.getInstance().banManager.isBanned(targetUUID)){
            sender.sendMessage("");
            sender.sendMessage("§6Raison : §c" + Main.getInstance().banManager.getReason(targetUUID));
            sender.sendMessage("§6Temps restant : §f" + Main.getInstance().banManager.getTimeLeft(targetUUID));
        }
        
        if(Main.getInstance().muteManager.isMuted(targetUUID)){
            sender.sendMessage("");
            sender.sendMessage("§6Raison : §c" + Main.getInstance().muteManager.getReason(targetUUID));
            sender.sendMessage("§6Temps restant : §f" + Main.getInstance().muteManager.getTimeLeft(targetUUID));
        }
 
 
        sender.sendMessage("§7-----------------------------------------------------");
        return;
    }
}