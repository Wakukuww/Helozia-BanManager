package fr.wakukuw.banmanager.commands;

import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.plugin.Command;
 
import java.util.UUID;

import fr.wakukuw.banmanager.Main;
import fr.wakukuw.banmanager.utils.TimeUnit;
 
public class MuteCommand extends Command {
 
    public MuteCommand(){
        super("mute");
    }
 
	@Override
    public void execute(CommandSender sender, String[] args) {
		
        if(args.length < 3){
            helpMessage(sender);
            return;
        }
 
        String targetName = args[0];
 
        if(!Main.getInstance().playerinfos.exist(targetName)){
            sender.sendMessage("�cCe joueur ne s'est jamais connect� au serveur !");
            return;
        }
 
        UUID targetUUID = Main.getInstance().playerinfos.getUUID(targetName);
 
        if(Main.getInstance().muteManager.isMuted(targetUUID)){
            sender.sendMessage("�cCe joueur est d�j� muet !");
            return;
        }
 
        String reason = "";
        for(int i = 2; i < args.length; i++){
            reason += args[i] + " ";
        }
 
        if(args[1].equalsIgnoreCase("perm")){
            Main.getInstance().muteManager.mute(targetUUID, -1, reason);
            sender.sendMessage("�aVous avez rendu muet �6" + targetName + " �c(Permanent) �apour : �e" + reason);
            return;
        }
 
        if(!args[1].contains(":")){
            helpMessage(sender);
            return;
        }
 
        int duration = 0;
        try {
            duration = Integer.parseInt(args[1].split(":")[0]);
        } catch(NumberFormatException e){
            sender.sendMessage("�cLa valeur 'dur�e' doit �tre un nombre !");
            return;
        }
 
        if(!TimeUnit.existFromShortcut(args[1].split(":")[1])){
            sender.sendMessage("�cCette unit� de temps n'existe pas !");
            for(TimeUnit units : TimeUnit.values()){
                sender.sendMessage("�b" + units.getName() + " �f: �e" + units.getShortcut());
            }
            return;
        }
 
        TimeUnit unit = TimeUnit.getFromShortcut(args[1].split(":")[1]);
        long banTime = unit.getToSecond() * duration;
 
        Main.getInstance().muteManager.mute(targetUUID, banTime, reason);
        sender.sendMessage("�aVous avez rendu muet �6" + targetName + " �b(" + duration + " " + unit.getName() + ") �apour : �e" + reason);
        return;
    }
    public void helpMessage(CommandSender sender){
        sender.sendMessage("�c/mute <joueur> perm <raison>");
        sender.sendMessage("�c/mute <joueur> <dur�e>:<unit�> <raison>");
    }
}
