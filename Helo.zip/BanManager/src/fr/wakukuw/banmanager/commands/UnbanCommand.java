package fr.wakukuw.banmanager.commands;

import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.plugin.Command;
 
import java.util.UUID;

import fr.wakukuw.banmanager.Main;
 
public class UnbanCommand extends Command {
 
    public UnbanCommand(){
        super("unban");
    }
 
    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length != 1){
            sender.sendMessage("�c/unban <joueur>");
            return;
        }
 
        String targetName = args[0];
 
        if(!Main.getInstance().playerinfos.exist(targetName)){
            sender.sendMessage("�cCe joueur ne s'est jamais connect� au serveur !");
            return;
        }
 
        UUID targetUUID = Main.getInstance().playerinfos.getUUID(targetName);
 
        if(!Main.getInstance().banManager.isBanned(targetUUID)){
            sender.sendMessage("�cCe joueur n'est pas banni !");
            return;
        }
 
        Main.getInstance().banManager.unban(targetUUID);
        sender.sendMessage("�aVous avez d�banni �6" + targetName);
        return;
    }
}