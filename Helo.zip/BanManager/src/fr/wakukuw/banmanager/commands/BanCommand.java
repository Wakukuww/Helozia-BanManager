package fr.wakukuw.banmanager.commands;

import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.plugin.Command;
 
import java.util.UUID;

import fr.wakukuw.banmanager.Main;
import fr.wakukuw.banmanager.utils.TimeUnit;
 
public class BanCommand extends Command {
 
    public BanCommand(){
        super("ban");
}

	@Override
    public void execute(CommandSender sender, String[] args) {
		
        if(args.length < 3){
            helpMessage(sender);
            return;
        }
 
        String targetName = args[0];
 
        if(!Main.getInstance().playerinfos.exist(targetName)){
            sender.sendMessage("�cCe joueur ne s'est jamais connect� au serveur !");
            return;
        }
 
        UUID targetUUID = Main.getInstance().playerinfos.getUUID(targetName);
 
        if(Main.getInstance().banManager.isBanned(targetUUID)){
            sender.sendMessage("�cCe joueur est d�j� banni !");
            return;
        }
 
        String reason = "";
        for(int i = 2; i < args.length; i++){
            reason += args[i] + " ";
        }
 
        if(args[1].equalsIgnoreCase("perm")){
        	if(!sender.hasPermission("modo")) {
            Main.getInstance().banManager.ban(targetUUID, -1, reason);
            sender.sendMessage("�aVous avez banni �6" + targetName + " �c(Permanent) �apour : �e" + reason);
            return;
        }
        
        else {
        	sender.sendMessage("�cVous ne pouvez mettre qu'une valeure de 7 jours maximum !");
        }
        }
 
        if(!args[1].contains(":")){
            helpMessage(sender);
            return;
        }
 
        int duration = 0;
        try {
            duration = Integer.parseInt(args[1].split(":")[0]);
        } catch(NumberFormatException e){
            sender.sendMessage("�cLa valeur 'dur�e' doit �tre un nombre !");
            return;
        }
 
        if(!TimeUnit.existFromShortcut(args[1].split(":")[1])){
            sender.sendMessage("�cCette unit� de temps n'existe pas !");
            for(TimeUnit units : TimeUnit.values()){
                sender.sendMessage("�b" + units.getName() + " �f: �e" + units.getShortcut());
            }
            return;
        }
 
        TimeUnit unit = TimeUnit.getFromShortcut(args[1].split(":")[1]);
        long banTime = unit.getToSecond() * duration;
 
        Main.getInstance().banManager.ban(targetUUID, banTime, reason);
        sender.sendMessage("�aVous avez banni �6" + targetName + " �b(" + duration + " " + unit.getName() + ") �apour : �e" + reason);
        return;
    }
 
    public void helpMessage(CommandSender sender){
        sender.sendMessage("�c/ban <joueur> perm <raison>");
        sender.sendMessage("�c/ban <joueur> <dur�e>:<unit�> <raison>");
    }
}