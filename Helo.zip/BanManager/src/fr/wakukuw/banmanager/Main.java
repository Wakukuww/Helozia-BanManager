package fr.wakukuw.banmanager;
 
import fr.wakukuw.banmanager.bans.BanManager;
import fr.wakukuw.banmanager.bans.MuteManager;
import fr.wakukuw.banmanager.commands.BanCommand;
import fr.wakukuw.banmanager.commands.CheckCommand;
import fr.wakukuw.banmanager.commands.LobbyCommand;
import fr.wakukuw.banmanager.commands.MuteCommand;
import fr.wakukuw.banmanager.commands.UnbanCommand;
import fr.wakukuw.banmanager.commands.UnmuteCommand;
import fr.wakukuw.banmanager.infos.PlayerInfos;
import fr.wakukuw.banmanager.listeners.PlayerJoin;
import fr.wakukuw.banmanager.listeners.PlayerMessage;
import fr.wakukuw.banmanager.mysql.MySQL;
import net.md_5.bungee.api.plugin.Plugin;


public class Main extends Plugin {
 
    private static Main instance;
    public MySQL mysql = new MySQL();
    public PlayerInfos playerinfos  = new PlayerInfos();
    
    //Managers
    public BanManager banManager = new BanManager();
    public MuteManager muteManager = new MuteManager();
 
    @Override
    public void onEnable() {
        instance = this;
        mysql.connect("5.42.158.26", 3306, "mc_ban", "mc_ban", "22Y9iG4WjB5Ui5JakCe4KnPy5Ca62RwxhW5RntDd24v6YTa855");

//Listeners
        getProxy().getPluginManager().registerListener(this, new PlayerJoin());
        getProxy().getPluginManager().registerListener(this, new PlayerMessage());
        
        //Bans
        getProxy().getPluginManager().registerCommand(this, new BanCommand());
        getProxy().getPluginManager().registerCommand(this, new UnbanCommand());
        
        //Check
        getProxy().getPluginManager().registerCommand(this, new CheckCommand());
        
        //Mute
        getProxy().getPluginManager().registerCommand(this, new MuteCommand());
        getProxy().getPluginManager().registerCommand(this, new UnmuteCommand());
        
        //Lobby
        getProxy().getPluginManager().registerCommand(this, new LobbyCommand());
        
        //Alert
        getProxy().getPluginManager().registerCommand(this, new LobbyCommand());
 
       
    }
 
    @Override
    public void onDisable() {
        mysql.disconnect();
    }
    
 
    public static Main getInstance() {
        return instance;
    }
}